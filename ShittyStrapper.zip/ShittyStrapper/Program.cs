﻿using System;
using System.Net;
using System.Threading;
using System.Diagnostics;
using System.IO.Compression;
using System.IO;

namespace ShittyStrapper
{
    class Program
    {
        #region Variable

        public static string FileName = ".\\Release.zip";
        public static string DirectoryName = ".\\Release";
        public static string ExeName = ".\\Cube x.exe";

        #endregion

        #region Make Easy To Write
        public static void EasyWrite(string print , ConsoleColor Color)
        {
            Console.ForegroundColor = Color;
            Console.WriteLine(print);
            Console.ResetColor();
        }
        #endregion

        #region CheckTheFilesExits
        public static void CheckFilesExits()
        {
            try
            {
                if (File.Exists(FileName))
                {
                    File.Delete(FileName);
                }

            }
            catch (Exception ex)
            {
                EasyWrite($"Something Went Wrong : {ex.ToString()}", ConsoleColor.Red);
            }

            Thread.Sleep(1000);

            try
            {
                if (Directory.Exists(DirectoryName))
                {
                    Directory.Delete(DirectoryName, true);
                }
            }
            catch (Exception ex)
            {
                EasyWrite($"Something Went Wrong : {ex.ToString()}", ConsoleColor.Red);
            }
        }
        #endregion

        #region KillProcess
        public static void KillProcess(string ProcessName)
        {
            try
            {
                foreach (Process pc in Process.GetProcessesByName(ProcessName))
                {
                    pc.Kill();
                    pc.WaitForExit();
                    pc.Dispose();
                }
            }
            catch (Exception ex)
            {
                EasyWrite($"Something Went Wrong : {ex.ToString()}", ConsoleColor.Red);
            }
        }
        #endregion

        #region ExtrackFiles
        public static void ExtrackSomeShit(string FilesName , string ExtrackDirectory)
        {
            try
            {
                ZipFile.ExtractToDirectory($".\\{FilesName}", Environment.CurrentDirectory + $".\\");
            }
            catch (Exception ex)
            {
                EasyWrite($"Something Went Wrong : {ex.ToString()}", ConsoleColor.Red);
            }
        }
        #endregion

        #region DownloadRequest
        public static void StartDowload()
        {
            Thread thread = new Thread(() =>
            {
                WebClient wc = new WebClient();
                wc.DownloadFileAsync(new Uri("https://cdn.discordapp.com/attachments/798554155811078163/816495409602101258/Release.zip"), FileName);
                wc.DownloadProgressChanged += Wc_DownloadProgressChanged;
                wc.DownloadFileCompleted += Wc_DownloadFileCompleted;
            }); thread.Start();
        }

        private static void Wc_DownloadFileCompleted(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
            if (e.Cancelled == false)
            {
                EasyWrite("Completed Downloading Requested Files!" , ConsoleColor.Yellow);
                Thread.Sleep(1000);

                ExtrackSomeShit(FileName, DirectoryName);
                EasyWrite("SuccessFulyy Extrackted Files!", ConsoleColor.Yellow);

                Thread.Sleep(1000);
                try
                {
                    if (File.Exists(FileName))
                    {
                        File.Delete(FileName);
                    }
                }
                catch (Exception ex)
                {
                    EasyWrite($"Something Went Wrong : {ex.ToString()}", ConsoleColor.Red);
                }

                Thread.Sleep(1000);

                EasyWrite("Enjoy Exploiting LOL", ConsoleColor.Yellow);

                //Process.Start($".\\{DirectoryName}\\{ExeName}");

                Thread.Sleep(1000);

                Environment.Exit(0);
            }
        }

        private static void Wc_DownloadProgressChanged(object sender, DownloadProgressChangedEventArgs e)
        {
            Console.Title = $"TotalByteToReceive : {e.TotalBytesToReceive} | BytesReceived : {e.BytesReceived} | Progress : {e.ProgressPercentage}%";
        }
        #endregion

        #region CheckNamedPipes
        public static void CheckPipes()
        {
            if (NamedPipes.NamedPipeExist(NamedPipes.luapipename))
            {
                KillProcess("RobloxPlayerBeta");
            }
        }
        #endregion

        #region MainMethod
        static void Main(string[] args)
        {
            CheckPipes();

            Thread.Sleep(1000);

            CheckFilesExits();
            EasyWrite("Check FullField.", ConsoleColor.Yellow);

            Thread.Sleep(700);

            StartDowload();   
            EasyWrite("SuccessFully Starting Request!", ConsoleColor.Yellow);   

            Console.ReadKey();
        }
        #endregion
    }
}
